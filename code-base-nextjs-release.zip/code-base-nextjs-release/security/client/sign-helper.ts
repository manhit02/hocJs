import crypto from "crypto";
import { env } from "next-runtime-env";
export const imageSignHelper = ({
  time,
  makerCode,
  startTime,
  endTime,
}: {
  time: number;
  makerCode: string;
  startTime: number;
  endTime: number;
}) => {
  return crypto
    .createHash("sha256")
    .update(
      `${time}${makerCode}${startTime}${endTime}${
        env('NEXT_PUBLIC_API_SECRET') || ""
      }`
    )
    .digest("hex");
};
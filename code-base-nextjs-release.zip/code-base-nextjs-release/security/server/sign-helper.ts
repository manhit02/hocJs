import { logError } from "@/utils/log-helper";
import crypto from "crypto";
import jwt from 'jsonwebtoken'
export const imageSignHelperSSR = ({
  time,
  makerCode,
  startTime,
  endTime,
}: {
  time: number;
  makerCode: string;
  startTime: number;
  endTime: number;
}) => {
  return crypto
    .createHash("sha256")
    .update(
      `${time}${makerCode}${startTime}${endTime}${
        process.env.API_SECRET || ""
      }`
    )
    .digest("hex");
};
export const getJWTImage: any = (token: string) => {
  try {
    return jwt.decode(token, { complete: true });
  } catch (error) {
    logError("getJWTImage", { error });
    return null;
  }
};

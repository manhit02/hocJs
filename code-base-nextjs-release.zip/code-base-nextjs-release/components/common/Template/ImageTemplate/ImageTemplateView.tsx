'use client'
import { renderImage } from "@/utils/client/render-helper";
import Image from "next/image";
export default function ImageTemplateView() {
    return (
        <div>
            <Image
                width={2560}
                height={1000}
                alt="Fast Image"
                src={renderImage('/assets/images/tet2025/tt11.png')}
            />
        </div>
    )
}
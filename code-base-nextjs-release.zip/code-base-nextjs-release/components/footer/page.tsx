const Footer = () => {
  return <footer>{/* tạo footer tại đây */}</footer>;
};

export default Footer;

'use client';
import { ImageProps } from 'next/image';
import React from 'react';
import Image from 'next/image';
import dayjs from 'dayjs';
import timezone  from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';
dayjs.extend(utc);
dayjs.extend(timezone);
import { imageSignHelper } from '@/security/client/sign-helper';
import { env } from 'next-runtime-env';
interface ImagePropsCustom extends ImageProps {
  startTime: number;
  endTime: number;
}
const SecureImage = (props: ImagePropsCustom) => {
  const time = dayjs().tz('Asia/Bangkok').unix();
  const makerCode = env('NEXT_PUBLIC_MAKER_CODE') ?? '';
  return (
    <Image
      {...props}
      alt={props.alt}
      loader={({ src, width: w, quality }) => {
        const q = quality || 75;
        return `${env('NEXT_PUBLIC_BASE_PATH')}/api/secure-image?url=${src}&startTime=${
          props.startTime
        }&endTime=${props.endTime}&time=${time}&sign=${imageSignHelper({
          time,
          makerCode,
          startTime: props.startTime,
          endTime: props.endTime,
        })}&w=${w}&q=${q}`;
      }}
    />
  );
};
export default SecureImage;

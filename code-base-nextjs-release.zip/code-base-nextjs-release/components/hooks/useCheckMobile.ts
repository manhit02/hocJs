import { isMobile } from "react-device-detect";
const useCheckMobile = () => {
  return isMobile;
};

export default useCheckMobile;

"use server";

import { ServerRequestBackend } from "@/types/request-server";
import dayjs from 'dayjs';
import timezone  from 'dayjs/plugin/timezone';
import utc from 'dayjs/plugin/utc';
dayjs.extend(utc);
dayjs.extend(timezone);

import crypto from "crypto";
import { logError, logInfo } from "@/utils/log-helper";
import axios, { AxiosResponse } from "axios";
import { createHttpAgent } from "@/http/temporal-loom";
import { requireAuth } from "./authen";
export const apiHelper = async (
  url: string,
  func: string,
  makerCode: string,
  data: any,
  fromIP?: string
) => {
  let res = {} as AxiosResponse;

  const token_info = await requireAuth();
  const full_path = process.env.API_BACKEND + url;
  const requestInfo = new ServerRequestBackend({
    time: dayjs().utc().unix(),
    sign: "",
    makerCode: makerCode,
    func: func,
    data: data,
    fromIP: fromIP || "",
  });
  const key = `${requestInfo.time}${requestInfo.makerCode}${requestInfo.func}${process.env.API_SECRET}`;
  const api_sign = crypto.createHash("sha256").update(key).digest("hex");
  requestInfo.sign = api_sign;
  try {
    res = await axios.post(full_path, requestInfo, {
      withCredentials: true,
      headers: {
        Authorization: `Bearer ${token_info.tokenValue}`,
      },
      httpAgent: createHttpAgent(),
    });

    logInfo(
      "apiHelper",
      { full_path, requestInfo, key, token: token_info.tokenValue },
      {
        HTTP_STATUS: res.status,
        STATUS_TEXT: res.statusText,
        code: res.data.code,
        mess: res.data.mess,
      }
    );
  } catch (error) {
    logError(
      "apiHelper",
      { full_path, requestInfo, key, token: token_info.tokenValue },
      { error }
    );
  }
  return res;
};
export const apiPlusHelper = async (
  url: string,  
) => {
  let res = {} as AxiosResponse;
  const full_path = process.env.API_PLUS + url;
  
  try {
    res = await axios.get(full_path);

    logInfo(
      "apiPlusHelper",
      { full_path },
      {
        HTTP_STATUS: res.status,
        STATUS_TEXT: res.statusText,
        code: res.data.code,
        mess: res.data.mess,
      }
    );
  } catch (error) {
    logError(
      "apiPlusHelper",
      { full_path },
      { error }
    );
  }
  return res;
};

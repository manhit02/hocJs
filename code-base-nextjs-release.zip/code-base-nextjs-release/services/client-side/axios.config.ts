"use client";
import axios from "axios";
import { logInfo } from "@/utils/log-helper";
import { env } from "next-runtime-env";
const instance = axios.create({
  baseURL: env('NEXT_PUBLIC_API_BACKEND'),
});
const instancePlus = axios.create({
  baseURL: env('NEXT_PUBLIC_API_PLUS'),
});
export const setToken = (token: string) => {
  if (!token) {
    logInfo("setToken", {}, { token });
  }
  instance.interceptors.request.use((config) => {
    config.headers.Authorization = `Bearer ${token}`;
    return config;
  });
};
export const AxiosConfig = () => {
  return instance;
};
export const AxiosPlusConfig = () => {
  return instancePlus;
};

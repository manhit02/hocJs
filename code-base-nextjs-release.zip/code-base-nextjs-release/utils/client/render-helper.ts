'use client';

import { env } from "next-runtime-env";

export const renderUrlImage = (url: string) => {
  if (process.env.NEXT_PUBLIC_MODE === "html") {
    return `url(${url})`;
  }
  let baseMedia = env('NEXT_PUBLIC_BASE_MEDIA');
  if (
    !baseMedia ||
    baseMedia !== undefined
  ) {
    url = `url(${baseMedia}${url})`;
  }
  return url;
};

export const renderImage = (url: string) => {
  if (process.env.NEXT_PUBLIC_MODE === "html") {
    return url;
  }
  let baseMedia = env('NEXT_PUBLIC_BASE_MEDIA');
  if (
    !baseMedia ||
    baseMedia !== undefined
  ) {
    url = `${baseMedia}${url}`;
  }
  return url;
};

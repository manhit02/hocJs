

export const renderUrlImageServer = (url: string) => {
  let baseMedia = process.env.BASE_MEDIA;
  let res = "";
  if (
    !baseMedia ||
    baseMedia !== undefined
  ) {
    res = `url(${baseMedia}${url})`;
  }
  return res;
};
export const renderImageServer = (url: string) => {
  let baseMedia = process.env.BASE_MEDIA;
  if (
    !baseMedia ||
    baseMedia !== undefined
  ) {
    url = `${baseMedia}${url}`;
  }
  return url;
};

export const renderTailwindBackgroudImage = (url: string) => {
  if (process.env.NEXT_PUBLIC_MODE === "html") {
    return `url(${url})`;
  }
  let baseMedia = process.env.BASE_MEDIA;
  if (
    !baseMedia ||
    baseMedia !== undefined
  ) {
    url = `url(${baseMedia}${url})`;
  }
  return url;
};
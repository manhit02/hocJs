'use client'
import crypto from "crypto";
import { env } from "next-runtime-env";

export class RequestBackend {
  time: number;
  sign: string;
  makerCode: string;
  func: string;
  fromIP: string;
  data: Object;

  constructor(
    { time, fromIP, sign, makerCode, func, data } = {
      time: 0,
      fromIP: "",
      sign: "",
      makerCode: "",
      func: "",
      data: {},
    }
  ) {
    this.time = time;
    this.fromIP = fromIP;
    this.sign = crypto
      .createHash("sha256")
      .update(
        `${time}${makerCode}${func}${
          env('NEXT_PUBLIC_API_SECRET') || ""
        }`
      )
      .digest("hex");
    this.makerCode = makerCode;
    this.func = func;
    this.data = data;
  }
}

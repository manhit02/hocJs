export class ServerRequestBackend {
  time: number;
  sign: string;
  makerCode: string;
  func: string;
  data: Object;
  fromIP: string;

  constructor(
    { time, fromIP, sign, makerCode, func, data } = {
      time: 0,
      fromIP: "",
      sign: "",
      makerCode: "",
      func: "",
      data: {},
    }
  ) {
    this.time = time;
    this.fromIP = fromIP;
    this.sign = sign;
    this.makerCode = makerCode;
    this.func = func;
    this.data = data;
  }
}

export interface ServerPropsParamRequest {
  url: string;
  func: string;
  data: any;
  fromIP?: string;
}

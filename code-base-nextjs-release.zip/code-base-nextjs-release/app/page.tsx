
import ImageTemplatePage from "@/components/common/Template/ImageTemplate/ImageTemplatePage";
import Template from "@/components/common/Template/Template";
import { Suspense } from "react";

export default function Home() {
  return (
    <main className="text-black">
      {/* phần Template này để demo, mọi người hãy xóa đi khi bắt đầu dựng html */}
      <Template />
      <Suspense fallback={<></>}>
        <ImageTemplatePage />
      </Suspense>
      <div className="w-full h-full flex justify-center">
        <div className="bg-background-demo w-[1113px] h-[687px] text-center content-center">
          <p className="text-[40px]">Hello world</p>
        </div>
      </div>
      {/*  */}
    </main>
  );
}

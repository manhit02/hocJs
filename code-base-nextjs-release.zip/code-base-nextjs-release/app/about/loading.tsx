
import { ShoppingLoader } from "@/components/common/Skeleton";
const Loading = () => {
  return (
    <div>
      <div>Page này About Us</div>
      <div>
        {" "}
        <ShoppingLoader />
      </div>
    </div>
  );
};

export default Loading;

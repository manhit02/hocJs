
import { ShoppingLoader } from "@/components/common/Skeleton";
const Loading = () => {
  return (
    <div>
      <div>Page này demo</div>
      <div>
        {" "}
        <ShoppingLoader />
      </div>
    </div>
  );
};

export default Loading;

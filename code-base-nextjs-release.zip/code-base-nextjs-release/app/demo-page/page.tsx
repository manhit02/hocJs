"use client";

const DemoPage = () => {
  
  return (
    <div className="text-black">
      <div className="flex flex-col p-5">
        <h3>Demo Page</h3>
      </div>
    </div>
  );
};

export default DemoPage;

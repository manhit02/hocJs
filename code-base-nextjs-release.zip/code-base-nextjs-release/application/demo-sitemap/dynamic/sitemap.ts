import { getLocationSSR } from "@/services/server-side/services-api/service-api";
import { CityInfo } from "@/types/apiTypes";
import { MetadataRoute } from "next"

const BASE_URL = process.env.BASE_WEB || ""
 
export async function generateSitemaps() {
  // Fetch the total number of products and calculate the number of sitemaps needed
  return []
}
 
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const res = await getLocationSSR();
  let list_demo: CityInfo[] = [];

  if (res.data && res.data.length > 0) {
    list_demo = res.data
  }
  return list_demo.map((demo) => ({
    url: `${BASE_URL}/demo-mage/${demo.locationID}`,
    lastModified: new Date(),
  }))
}
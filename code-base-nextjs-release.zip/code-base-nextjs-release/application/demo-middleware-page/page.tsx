import React from "react";

const TaiGame = async (props: { searchParams: Promise<{ os: string }> }) => {
  const searchParams = await props.searchParams;
  return (
    <div>
      <h1 style={{ textAlign: "center", marginTop: "10%" }}>
        Xin Chào !!! Thiết bị: {searchParams.os}
      </h1>
      <div style={{ marginTop: "50%" }}></div>
    </div>
  );
};

export default TaiGame;

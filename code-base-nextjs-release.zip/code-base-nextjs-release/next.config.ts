import type { NextConfig } from 'next'
const nextConfig: NextConfig  = {
  output: process.env.NEXT_PUBLIC_MODE === "web" ? "standalone" : "export",
  basePath: "", //VD: /austore
  images: {
    unoptimized: process.env.NEXT_PUBLIC_MODE === "web" ? false : true,
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
      {
        hostname: "localhost",
      },
    ],
  }
};

export default nextConfig
